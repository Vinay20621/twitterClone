import React from "react";

function Footer() {
  return <div className="footer">Copyright © 2022</div>;
}

export default Footer;
